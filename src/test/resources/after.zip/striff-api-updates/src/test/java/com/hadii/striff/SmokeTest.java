package com.hadii.striff;

import com.hadii.striff.api.StriffAPIApplication;
import com.hadii.striff.api.controllers.HealthCheckController;
import com.hadii.striff.api.controllers.LanguagesController;
import com.hadii.striff.api.controllers.StriffController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(classes = StriffAPIApplication.class)
public class SmokeTest {

    @Autowired
    private HealthCheckController healthCheckController;

    @Autowired
    private LanguagesController languagesController;

    @Autowired
    private StriffController striffController;

    @Test
    public void contextLoads() {
        assertThat(this.healthCheckController).isNotNull();
        assertThat(this.languagesController).isNotNull();
        assertThat(this.striffController).isNotNull();
    }
}
