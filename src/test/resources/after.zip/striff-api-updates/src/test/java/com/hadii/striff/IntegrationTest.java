package com.hadii.striff;

import com.hadii.striff.api.StriffAPIApplication;
import com.hadii.striff.api.controllers.LanguagesController;
import com.hadii.striff.api.controllers.StriffController;
import com.hadii.striff.diagram.StriffDiagram;
import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.FileWriter;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = StriffAPIApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@TestPropertySource(properties = {
                "spring.cache.type=none"
})
public class IntegrationTest {

        @LocalServerPort
        private int port;

        @Autowired
        private MockMvc mockMvc;

        @Autowired
        private TestRestTemplate restTemplate;

        @BeforeAll
        public static void clearDatabaseBeforeAllTests(@Autowired MongoTemplate mongoTemplate) {
                mongoTemplate.getDb().drop();
        }

        @AfterAll
        public static void clearDatabaseAfterAllTests(@Autowired MongoTemplate mongoTemplate) {
                mongoTemplate.getDb().drop();
        }

        @Test
        public void healthCheckTest() throws Exception {
                assertThat(this.restTemplate
                                .getForEntity("http://localhost:" + this.port + StriffAPIApplication.BASE_URI
                                                + "/health",
                                                String.class)
                                .getStatusCode().value()).isEqualTo(200);
        }

        @Test
        public void languagesEndpointTest() throws Exception {
                assertThat(this.restTemplate
                                .getForObject("http://localhost:" + this.port + StriffAPIApplication.BASE_URI
                                                + LanguagesController.LANGUAGES_URI, String.class))
                                .contains("java");
        }

        @Test
        public void githubStriffSuccessTest() throws Exception {
                MvcResult result = this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/Zir0-93/repos/junit5/pulls/1?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().isOk())
                                .andExpect(jsonPath("$.striffs").exists())
                                .andExpect(jsonPath("$.striffs", hasSize(1)))
                                .andExpect(jsonPath("$.striffs[0].source", is("github")))
                                .andExpect(jsonPath("$.baseRepoOwner", is("Zir0-93")))
                                .andExpect(jsonPath("$.baseRepoName", is("junit5")))
                                .andExpect(jsonPath("$.baseBranchSha", is("25d727a186a3151c6cf22619c989082cad39b543")))
                                .andExpect(jsonPath("$.headRepoOwner", is("Zir0-93")))
                                .andExpect(jsonPath("$.headRepoName", is("junit5")))
                                .andExpect(jsonPath("$.headBranchSha", is("9743eb1808b3a991cfe672d9333d81b0f5fc1118")))
                                .andExpect(jsonPath("$.pullUrl",
                                                is("https://api.github.com/repos/Zir0-93/junit5/pulls/1")))
                                .andExpect(jsonPath("$.pullId", is("518940067")))
                                .andExpect(jsonPath("$.pullNo", is("1")))
                                .andReturn();
                String encodedSvg = JsonPath.read(result.getResponse().getContentAsString(),
                                "$.striffs[0].base64encodedSVGCode");
                FileWriter writer = new FileWriter("/tmp/striff.svg");
                writer.write(new String(StriffDiagram.decompressAndDecodeSvg(encodedSvg)));
                writer.close();
        }

        @Test
        public void githubStriffLoadExistingTest() throws Exception {
                MvcResult result1 = this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/Zir0-93/repos/junit5/pulls/1?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().isOk()).andReturn();
                String operationIdString = JsonPath.read(result1.getResponse().getContentAsString(), "$.operationId");
                MvcResult result2 = this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/Zir0-93/repos/junit5/pulls/1?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().isOk()).andReturn();
                assertEquals(JsonPath.read(result2.getResponse().getContentAsString(), "$.operationId"),
                                operationIdString);

        }

        @Test
        public void githubStriffInvalidTokenTest() throws Exception {
                this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/Zir0-93/repos/junit5/pulls/1?updated_at=2014-03-03T18:58:10Z")
                                .header("Authorization", "token fakeToken"))
                                .andExpect(status().is(403))
                                .andExpect(jsonPath("$.errorMessage").exists())
                                .andReturn();
        }

        @Test
        public void githubSetContentTypeTest() throws Exception {
                this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                        + "/owners/Zir0-93/repos/junit5/pulls/1?updated_at=2014-03-03T18:58:10Z")
                        .header("Authorization", "token fakeToken")
                        .header("Accept", "application/json"))
                        .andExpect(status().is(403))
                        .andExpect(jsonPath("$.errorMessage").exists())
                        .andReturn();
        }

        @Test
        public void githubStriffNoChangesTest() throws Exception {
                this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/Zir0-93/repos/junit5/pulls/2?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().is(200))
                                .andExpect(jsonPath("$.striffs").isEmpty())
                                .andReturn();
        }

        @Test
        public void githubStriffNoSupportedLangsTest() throws Exception {
                this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/Zir0-93/repos/presentations/pulls/2?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().is(200))
                                .andExpect(jsonPath("$.striffs").isEmpty())
                                .andReturn();
        }

        @Test
        public void githubStriffNonAccessibleBranchTest() throws Exception {
                this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/hadii-tech/repos/production-ready-prestashop/pulls/3?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().is(400))
                                .andExpect(jsonPath("$.errorMessage").exists())
                                .andReturn();
        }

        @Test
        public void githubStriffWrongPRInfoTest() throws Exception {
                this.mockMvc.perform(get(StriffAPIApplication.BASE_URI + StriffController.STRIFF_URI
                                + "/owners/hadii-tech/repos/prowefduction-ready-prefwefwfestashop/pulls/3?updated_at=2014-03-03T18:58:10Z"))
                                .andExpect(status().is(400))
                                .andExpect(jsonPath("$.errorMessage").exists())
                                .andReturn();
        }
}
