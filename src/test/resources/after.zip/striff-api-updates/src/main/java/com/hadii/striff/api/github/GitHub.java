package com.hadii.striff.api.github;

import com.hadii.clarpse.compiler.ProjectFiles;
import com.hadii.striff.api.data.GHStriffRequestInfo;
import com.hadii.striff.api.exception.InternalStriffException;
import org.apache.commons.io.IOUtils;
import org.eclipse.egit.github.core.PullRequest;
import org.eclipse.egit.github.core.client.GitHubClient;
import org.eclipse.egit.github.core.client.RequestException;
import org.eclipse.egit.github.core.service.PullRequestService;
import org.eclipse.egit.github.core.service.RepositoryService;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.nio.file.AccessDeniedException;
public class GitHub {

    private final GitHubClient client;
    private String ghHostName;
    private String token;

    public GitHub(String ghHostName, String token) throws InternalStriffException {
        if (ghHostName == null || ghHostName.isEmpty()) {
            throw new InternalStriffException("A valid GitHub API host name is not set!");
        }
        this.ghHostName = ghHostName;
        this.token = token;
        this.client = this.getClient(ghHostName, token);
    }

    public ProjectFiles githubProjectFiles(String repoOwner, String repoName,
            String ref)
            throws Exception {
        String url = "https://" + this.ghHostName + "/repos/" + repoOwner + "/" + repoName + "/zipball/"
                + URLEncoder.encode(ref.trim(), StandardCharsets.UTF_8);
        final URL repoUrl = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) repoUrl.openConnection();
        if (token != null && !token.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + token);
        }
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        IOUtils.copy(new BufferedInputStream(conn.getInputStream(), 1024), baos);
        ProjectFiles files = new ProjectFiles(new ByteArrayInputStream(baos.toByteArray()));
        files.shiftSubDirsLeft();
        return files;
    }

    private GitHubClient getClient(String apiUrl, String token) {
        GitHubClient client = new GitHubClient(apiUrl);
        if (token != null && !token.isEmpty()) {
            client.setOAuth2Token(token);
        }
        this.token = token;
        return client;
    }

    public GitHubClient validateRepoReadAccess(String repoOwner, String repoName, String pullNo)
            throws IllegalArgumentException, AccessDeniedException {
        try {
            PullRequest pull = new PullRequestService(this.client)
                    .getPullRequest(new RepositoryService(this.client)
                            .getRepository(repoOwner, repoName), Integer.parseInt(pullNo));
            if (pull.getHead() == null
                    || pull.getHead().getRepo() == null
                    || pull.getHead().getRepo().getOwner() == null
                    || pull.getHead().getSha() == null
                    || pull.getBase() == null
                    || pull.getBase().getRepo() == null
                    || pull.getBase().getRepo().getOwner() == null
                    || pull.getBase().getSha() == null) {
                throw new Exception("One or more required pull request values are null!");
            }
        } catch (RequestException e) {
            if (e.getStatus() == 401) {
                throw new AccessDeniedException("Bad credentials: Access denied to the repository.");
            }
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "There was a problem accessing some of this pull requests' data, it may not be "
                            + "accessible anymore or the supplied credentials are invalid/insufficient.");
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "There was a problem accessing some of this pull requests' data, it may not be "
                            + "accessible anymore or the supplied credentials are invalid/insufficient.");
        }
        return this.client;
    }

    public GHStriffRequestInfo striffRequestInfo(String owner, String repo, String pullId) throws IOException {
        PullRequest pullRequest;
        pullRequest = new PullRequestService(this.client)
                .getPullRequest(new RepositoryService(this.client).getRepository(owner, repo),
                        Integer.parseInt(pullId));
        return new GHStriffRequestInfo(
                pullRequest.getHead().getRepo().getOwner().getLogin(),
                pullRequest.getHead().getRepo().getName(),
                pullRequest.getHead().getSha(),
                pullRequest.getBase().getRepo().getOwner().getLogin(),
                pullRequest.getBase().getRepo().getName(),
                pullRequest.getBase().getSha(),
                pullRequest.getUrl(),
                String.valueOf(pullRequest.getNumber()),
                String.valueOf(pullRequest.getId()));
    }
}
