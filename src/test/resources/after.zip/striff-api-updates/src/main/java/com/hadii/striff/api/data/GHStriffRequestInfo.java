package com.hadii.striff.api.data;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "headRepoOwner",
        "headRepoName",
        "headSha",
        "baseRepoOwner",
        "baseRepoName",
        "baseSha",
        "pullURL",
        "pullNo",
        "pullId"
})
public class GHStriffRequestInfo implements Serializable {

    private static final long serialVersionUID = -2358985816125834745L;
    @JsonProperty("headRepoOwner")
    private String headRepoOwner;
    @JsonProperty("headRepoName")
    private String headRepoName;
    @JsonProperty("headSha")
    private String headSha;
    @JsonProperty("baseRepoOwner")
    private String baseRepoOwner;
    @JsonProperty("baseRepoName")
    private String baseRepoName;
    @JsonProperty("baseSha")
    private String baseSha;
    @JsonProperty("pullURL")
    private String pullURL;
    @JsonProperty("pullNo")
    private String pullNo;
    @JsonProperty("pullId")
    private String pullId;
    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<>();

    /**
     * No args constructor for use in serialization.
     */
    public GHStriffRequestInfo() {
    }

    public GHStriffRequestInfo(String headRepoOwner, String headRepoName, String headSha, String baseRepoOwner,
            String baseRepoName, String baseSha, String pullURL, String pullNo,
            String pullId) {
        super();
        this.headRepoOwner = headRepoOwner;
        this.headRepoName = headRepoName;
        this.headSha = headSha;
        this.baseRepoOwner = baseRepoOwner;
        this.baseRepoName = baseRepoName;
        this.baseSha = baseSha;
        this.pullURL = pullURL;
        this.pullNo = pullNo;
        this.pullId = pullId;
    }

    @JsonProperty("headRepoOwner")
    public String getHeadRepoOwner() {
        return this.headRepoOwner;
    }

    @JsonProperty("headRepoOwner")
    public void setHeadRepoOwner(String headRepoOwner) {
        this.headRepoOwner = headRepoOwner;
    }

    @JsonProperty("headRepoName")
    public String getHeadRepoName() {
        return this.headRepoName;
    }

    @JsonProperty("headRepoName")
    public void setHeadRepoName(String headRepoName) {
        this.headRepoName = headRepoName;
    }

    @JsonProperty("headSha")
    public String getHeadSha() {
        return this.headSha;
    }

    @JsonProperty("headSha")
    public void setHeadSha(String headSha) {
        this.headSha = headSha;
    }

    @JsonProperty("baseRepoOwner")
    public String getBaseRepoOwner() {
        return this.baseRepoOwner;
    }

    @JsonProperty("baseRepoOwner")
    public void setBaseRepoOwner(String baseRepoOwner) {
        this.baseRepoOwner = baseRepoOwner;
    }

    @JsonProperty("baseRepoName")
    public String getBaseRepoName() {
        return this.baseRepoName;
    }

    @JsonProperty("baseRepoName")
    public void setBaseRepoName(String baseRepoName) {
        this.baseRepoName = baseRepoName;
    }

    @JsonProperty("baseSha")
    public String getBaseSha() {
        return this.baseSha;
    }

    @JsonProperty("baseSha")
    public void setBaseSha(String baseSha) {
        this.baseSha = baseSha;
    }

    @JsonProperty("pullURL")
    String getPullUrl() {
        return this.pullURL;
    }

    @JsonProperty("pullURL")
    public void setPrUrl(String pullURL) {
        this.pullURL = pullURL;
    }

    @JsonProperty("pullNo")
    String getPullNo() {
        return this.pullNo;
    }

    @JsonProperty("pullNo")
    public void setPullNo(String pullNo) {
        this.pullNo = pullNo;
    }

    @JsonProperty("pullId")
    public String getPrId() {
        return this.pullId;
    }

    @JsonProperty("pullId")
    public void setPrId(String pullId) {
        this.pullId = pullId;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("headRepoOwner", this.headRepoOwner)
                .append("headRepoName", this.headRepoName).append("headSha", this.headSha)
                .append("baseRepoOwner", this.baseRepoOwner)
                .append("baseRepoName", this.baseRepoName)
                .append("baseSha", this.baseSha).append("pullURL", this.pullURL)
                .append("pullNo", this.pullNo).append("pullId", this.pullId)
                .append("additionalProperties", this.additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(this.pullNo).append(this.baseSha).append(this.baseRepoName)
                .append(this.pullId).append(this.baseRepoOwner).append(this.additionalProperties).append(this.headSha)
                .append(this.pullURL).append(this.headRepoOwner).append(this.headRepoName)
                .toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof GHStriffRequestInfo)) {
            return false;
        }
        GHStriffRequestInfo rhs = ((GHStriffRequestInfo) other);
        return new EqualsBuilder().append(this.pullNo, rhs.pullNo).append(this.baseSha, rhs.baseSha)
                .append(this.baseRepoName, rhs.baseRepoName).append(this.pullId, rhs.pullId)
                .append(this.baseRepoOwner, rhs.baseRepoOwner)
                .append(this.additionalProperties, rhs.additionalProperties).append(this.headSha, rhs.headSha)
                .append(this.pullURL, rhs.pullURL)
                .append(this.headRepoOwner, rhs.headRepoOwner).append(this.headRepoName, rhs.headRepoName).isEquals();
    }
}
