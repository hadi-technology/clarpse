package com.hadii.striff.api.core;

import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document
public interface StriffMetadata {

    int getSize();

    long getGenerationTime();

    Date getDate();

    String getBase64encodedSVGCode();

    String getDiagramRelsJSON();

    String getChangeSetJSON();

    String getDiagramCmpsJSON();

    String getSource();

}
