package com.hadii.striff.api.core;

import com.hadii.clarpse.compiler.ProjectFiles;
import com.hadii.striff.api.data.GHStriffRequestInfo;
import com.hadii.striff.api.exception.InternalStriffException;
import com.hadii.striff.api.github.GitHub;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class GitHubStriffProcessor {

        private static final Logger LOGGER = LoggerFactory.getLogger(GitHubStriffProcessor.class);

        public List<StriffMetadata> striffs(GHStriffRequestInfo ghStriffRequestInfo, GitHub gh)
                        throws IOException, InternalStriffException {
                List<StriffMetadata> striffs = new ArrayList<>();
                try {
                        generateStriffs(
                                        ghStriffRequestInfo,
                                        gh.githubProjectFiles(ghStriffRequestInfo.getBaseRepoOwner(),
                                                        ghStriffRequestInfo.getBaseRepoName(),
                                                        ghStriffRequestInfo.getBaseSha()),
                                        gh.githubProjectFiles(ghStriffRequestInfo.getHeadRepoOwner(),
                                                        ghStriffRequestInfo.getHeadRepoName(),
                                                        ghStriffRequestInfo.getHeadSha()),
                                        striffs);
                } catch (Exception e) {
                        e.printStackTrace();
                        throw new InternalStriffException(
                                        "Failed to process a Striff Operation for the following request:\n"
                                                        + ghStriffRequestInfo.toString(), e);
                }
                if (striffs.isEmpty()) {
                        LOGGER.info("No striffs (of any kind) were generated for pull request "
                                        + ghStriffRequestInfo.getPrId() + " in repo: "
                                        + ghStriffRequestInfo.getBaseRepoOwner() + "/"
                                        + ghStriffRequestInfo.getBaseRepoName());
                }
                return striffs;
        }

        private void generateStriffs(GHStriffRequestInfo ghStriffRequestInfo,
                        ProjectFiles oldFiles, ProjectFiles newFiles, List<StriffMetadata> striffs) throws Exception {
                LOGGER.info("Executing Striff Operation for GitHub repo - "
                                + ghStriffRequestInfo.getBaseRepoOwner() + "/"
                                + ghStriffRequestInfo.getBaseRepoName()
                                + " and pull: " + ghStriffRequestInfo.getPrId());
                striffs.addAll(new StriffProcessor().process(
                                oldFiles,
                                newFiles,
                                "github"));
                LOGGER.info("Successfully generated striffs for pull request: "
                                + ghStriffRequestInfo.getPrId() + " in repo: "
                                + ghStriffRequestInfo.getBaseRepoOwner() + "/"
                                + ghStriffRequestInfo.getBaseRepoName());
        }
}
