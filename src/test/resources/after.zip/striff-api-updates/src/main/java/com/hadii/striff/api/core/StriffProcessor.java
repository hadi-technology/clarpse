package com.hadii.striff.api.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hadii.clarpse.compiler.ProjectFiles;
import com.hadii.striff.StriffOperation;
import com.hadii.striff.diagram.StriffDiagram;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class StriffProcessor {
    private static ObjectMapper mapper = new ObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(GitHubStriffProcessor.class);

    public List<StriffMetadata> process(ProjectFiles oldFiles, ProjectFiles newFiles, String reqSource)
            throws Exception {
        long startTime = System.nanoTime();
        List<StriffDiagram> diagrams = new StriffOperation(oldFiles, newFiles).result().diagrams();
        List<StriffMetadata> striffDiagramMetadata = new ArrayList<>();
        diagrams.forEach(diagram -> {
            try {
                striffDiagramMetadata.add(new DefaultStriffMetadata(
                        diagram.compressedSVG(),
                        (System.nanoTime() - startTime),
                        new Date(),
                        diagram.cmps().size(),
                        reqSource,
                        mapper.writeValueAsString(diagram.relations()),
                        mapper.writeValueAsString(diagram.changeSet()),
                        mapper.writeValueAsString(diagram.cmps())));
            } catch (IOException e) {
                LOGGER.error("Error while process striffs!", e);
                throw new RuntimeException("Could not process striff diagram!", e);
            }
        });
        return striffDiagramMetadata;
    }
}
