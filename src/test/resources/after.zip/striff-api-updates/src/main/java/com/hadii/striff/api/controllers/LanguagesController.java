package com.hadii.striff.api.controllers;

import com.hadii.clarpse.compiler.Lang;
import com.hadii.striff.api.StriffAPIApplication;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = StriffAPIApplication.BASE_URI)
public class LanguagesController {

    public static final String LANGUAGES_URI = "/languages";

    /**
     * Returns a list of programming languages supported by this API.
     */
    @RequestMapping(value = LANGUAGES_URI, method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
    @ResponseBody
    @Cacheable("languages")
    public String languages() {
        final List<String> supportedLanguages = new ArrayList<String>();
        for (final Lang supportedLanguage : Lang.supportedLanguages()) {
            supportedLanguages.add(supportedLanguage.value().toLowerCase());
        }
        return StringUtils.join(supportedLanguages, ',');
    }
}
