package com.hadii.striff.api.data;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

@Component
public interface GHStriffResultInfoRepository extends MongoRepository<GHStriffResultInfo, String> {

    GHStriffResultInfo findByBaseRepoOwnerAndBaseRepoNameAndBaseBranchShaAndHeadRepoOwnerAndHeadRepoNameAndHeadBranchSha(
            String baseRepoOwner, String baseRepoName, String baseBranchSha, String headRepoOwner, String headRepoName,
            String headBranchSha);
}
