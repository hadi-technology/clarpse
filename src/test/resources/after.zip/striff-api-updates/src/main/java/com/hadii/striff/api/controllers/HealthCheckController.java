package com.hadii.striff.api.controllers;

import com.hadii.striff.api.StriffAPIApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = StriffAPIApplication.BASE_URI)
public class HealthCheckController {

    @RequestMapping(value = "/health", method = RequestMethod.GET)
    @ResponseBody
    public String testController() {
        return "success!";
    }
}
