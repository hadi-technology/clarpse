package com.hadii.striff.api.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import io.sentry.Sentry;

import java.io.IOException;
import java.nio.file.AccessDeniedException;

@ControllerAdvice
public class ExceptionHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHelper.class);

    private record JsonResponse(String errorMessage) {}

    @ExceptionHandler(value = { Exception.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public JsonResponse handleException(Exception ex) {
        LOGGER.error("Exception while generating striffs: ", ex);
        Sentry.captureException(ex);
        return new JsonResponse("An internal error was encountered while processing your request, our team"
                + " has been notified and will fix the issue as soon as possible.");
    }

    @ExceptionHandler(value = { AccessDeniedException.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public JsonResponse handleAccessDeniedException(AccessDeniedException ex) {
        LOGGER.error("Access Denied Exception: ", ex);
        return new JsonResponse(ex.getLocalizedMessage());
    }

    @ExceptionHandler(value = { IllegalArgumentException.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public JsonResponse handleIllegalArgumentException(IllegalArgumentException ex) {
        LOGGER.error("Illegal Argument Exception: ", ex);
        return new JsonResponse(ex.getMessage());
    }

    @ExceptionHandler(value = { InternalStriffException.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public JsonResponse handleInternalStriffException(InternalStriffException ex) {
        Sentry.captureException(ex);
        return new JsonResponse("An internal error was encountered while processing your request, our team"
                + " has been notified and will fix the issue as soon as possible.");
    }

    @ExceptionHandler(value = { IOException.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public JsonResponse handleIOException(IOException ex) {
        Sentry.captureException(ex);
        return new JsonResponse("An internal error was encountered while processing your request, our team"
                + " has been notified and will fix the issue as soon as possible.");
    }
}
