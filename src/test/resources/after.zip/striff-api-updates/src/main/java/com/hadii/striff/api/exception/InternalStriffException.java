package com.hadii.striff.api.exception;

public class InternalStriffException extends Exception {
    public InternalStriffException(String errorMessage, Throwable cause) {
        super(errorMessage, cause);
    }

    public InternalStriffException(String errorMessage) {
        super(errorMessage);
    }
}
