package com.hadii.striff.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class StriffAPIApplication {

    public static final String BASE_URI = "/api/v1";

    public static void main(final String[] args) {
        SpringApplication.run(StriffAPIApplication.class, args);
    }
}
