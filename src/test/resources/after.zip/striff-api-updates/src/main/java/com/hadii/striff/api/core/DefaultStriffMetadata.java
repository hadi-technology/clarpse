package com.hadii.striff.api.core;

import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document
public class DefaultStriffMetadata implements StriffMetadata {
    private long generationTime;
    private Date date;
    private String source;
    private int size;
    private String base64encodedSVGCode;
    private String diagramRelsJSON;
    private String changeSetJSON;
    private String diagramCmpsJSON;

    public DefaultStriffMetadata(String base64encodedSVGCode,
            long generationTime, Date date,
            int size, String source,
            String diagramRelsJSON, String changeSetJSON, String diagramCmpsJSON) {
        this.generationTime = generationTime;
        this.size = size;
        this.date = date;
        this.source = source;
        this.base64encodedSVGCode = base64encodedSVGCode;
        this.diagramRelsJSON = diagramRelsJSON;
        this.changeSetJSON = changeSetJSON;
        this.diagramCmpsJSON = diagramCmpsJSON;
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public long getGenerationTime() {
        return generationTime;
    }

    @Override
    public Date getDate() {
        return date;
    }

    @Override
    public String getBase64encodedSVGCode() {
        return base64encodedSVGCode;
    }

    @Override
    public String getDiagramRelsJSON() {
        return diagramRelsJSON;
    }

    @Override
    public String getChangeSetJSON() {
        return changeSetJSON;
    }

    @Override
    public String getDiagramCmpsJSON() {
        return diagramCmpsJSON;
    }

    @Override
    public String getSource() {
        return source;
    }
}
