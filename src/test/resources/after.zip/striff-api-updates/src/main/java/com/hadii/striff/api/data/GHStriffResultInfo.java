package com.hadii.striff.api.data;

import com.hadii.striff.api.core.StriffMetadata;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document
public class GHStriffResultInfo {

    private List<StriffMetadata> striffs = new ArrayList<>();
    private String baseRepoOwner;
    private String baseRepoName;
    private String baseBranchSha;
    private String headRepoOwner;
    private String headRepoName;
    private String pullNo;
    private String headBranchSha;
    private String pullUrl;
    private String pullId;
    @Id
    private String operationId;

    public GHStriffResultInfo(GHStriffRequestInfo ghStriffRequestInfo,
            List<StriffMetadata> striffs) {
        this.baseRepoOwner = ghStriffRequestInfo.getBaseRepoOwner();
        this.baseRepoName = ghStriffRequestInfo.getBaseRepoName();
        this.baseBranchSha = ghStriffRequestInfo.getBaseSha();
        this.headRepoOwner = ghStriffRequestInfo.getHeadRepoOwner();
        this.headRepoName = ghStriffRequestInfo.getHeadRepoName();
        this.headBranchSha = ghStriffRequestInfo.getHeadSha();
        this.pullNo = ghStriffRequestInfo.getPullNo();
        this.pullUrl = ghStriffRequestInfo.getPullUrl();
        this.pullId = ghStriffRequestInfo.getPrId();
        this.striffs = striffs;
    }

    public GHStriffResultInfo() {
    }

    public String getOperationId() {
        return this.operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public List<StriffMetadata> getStriffs() {
        return this.striffs;
    }

    public void setStriffs(List<StriffMetadata> striffs) {
        this.striffs = striffs;
    }

    public String getBaseRepoOwner() {
        return this.baseRepoOwner;
    }

    public void setBaseRepoOwner(String baseRepoOwner) {
        this.baseRepoOwner = baseRepoOwner;
    }

    public String getBaseRepoName() {
        return this.baseRepoName;
    }

    public void setBaseRepoName(String baseRepoName) {
        this.baseRepoName = baseRepoName;
    }

    public String getBaseBranchSha() {
        return this.baseBranchSha;
    }

    public void setBaseBranchSha(String baseBranchSha) {
        this.baseBranchSha = baseBranchSha;
    }

    public String getHeadRepoOwner() {
        return this.headRepoOwner;
    }

    public void setHeadRepoOwner(String headRepoOwner) {
        this.headRepoOwner = headRepoOwner;
    }

    public String getHeadRepoName() {
        return this.headRepoName;
    }

    public void setHeadRepoName(String headRepoName) {
        this.headRepoName = headRepoName;
    }

    public String getPullNo() {
        return this.pullNo;
    }

    public void setPullNo(String pullNo) {
        this.pullNo = pullNo;
    }

    public String getHeadBranchSha() {
        return this.headBranchSha;
    }

    public void setHeadBranchSha(String headBranchSha) {
        this.headBranchSha = headBranchSha;
    }

    public String getPullUrl() {
        return this.pullUrl;
    }

    public void setPullUrl(String pullUrl) {
        this.pullUrl = pullUrl;
    }

    public String getPullId() {
        return this.pullId;
    }

    public void setPullId(String pullId) {
        this.pullId = pullId;
    }

    @Override
    public boolean equals(Object o) {
        if (o != null) {
            if (getClass() != o.getClass()) {
                return false;
            }
            return ((GHStriffResultInfo) o).getPullId().equals(this.pullId);
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return this.pullUrl.hashCode();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("headRepoOwner", this.headRepoOwner)
                .append("headRepoName", this.headRepoName)
                .append("headSha", this.headBranchSha)
                .append("baseRepoOwner", this.baseRepoOwner)
                .append("baseRepoName", this.baseRepoName)
                .append("baseSha", this.baseBranchSha)
                .append("pullUrl", this.pullUrl)
                .append("pullNo", this.pullNo)
                .append("pullId", this.pullId).toString();
    }
}