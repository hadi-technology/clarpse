package com.hadii.striff.api.controllers;

import com.hadii.clarpse.compiler.ProjectFiles;
import com.hadii.striff.api.StriffAPIApplication;
import com.hadii.striff.api.core.GitHubStriffProcessor;
import com.hadii.striff.api.core.StriffMetadata;
import com.hadii.striff.api.core.StriffProcessor;
import com.hadii.striff.api.data.GHStriffRequestInfo;
import com.hadii.striff.api.data.GHStriffResultInfo;
import com.hadii.striff.api.data.GHStriffResultInfoRepository;
import com.hadii.striff.api.exception.InternalStriffException;
import com.hadii.striff.api.github.GitHub;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.AccessDeniedException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.zip.ZipInputStream;

@Controller
@RequestMapping(value = StriffAPIApplication.BASE_URI)
public class StriffController {

    public static final String STRIFF_URI = "/github/striffs";

    private static final Logger LOGGER = LoggerFactory.getLogger(StriffController.class);

    @Autowired
    private GHStriffResultInfoRepository gHStriffResultInfoRepository;

    /**
     * Generates and returns striff report metadata for a given GitHub pull request.
     */
    @RequestMapping(value = STRIFF_URI + "/owners/{owner}/repos/{repo}/pulls/{pull_id}", method = RequestMethod.GET)
    @ResponseBody
    @Cacheable("github-striffs")
    public GHStriffResultInfo generateStriffs(
            @PathVariable("owner") String owner,
            @PathVariable("repo") String repo,
            @PathVariable("pull_id") String pullNo,
            @RequestParam(value = "updated_at", required = true) String updatedAt,
            @RequestParam(value = "gh_hostname", defaultValue = "api.github.com") String ghHostName,
            @RequestHeader(value = "Authorization", defaultValue = "") String ghBearerToken)
            throws IllegalArgumentException, InternalStriffException, IOException, AccessDeniedException {
        if (!ghBearerToken.isEmpty()) {
            ghBearerToken = ghBearerToken.replace("token", "").trim();
        }
        LOGGER.info("New GitHub striff request with " + "owner: " + owner + ", repo: " + repo + ", "
                + "pull request: " + pullNo + ", UpdateAt: " + updatedAt + ", Token provided: "
                + !ghBearerToken.isEmpty());
        GitHub gh = new GitHub(ghHostName, ghBearerToken);
        gh.validateRepoReadAccess(owner, repo, pullNo);
        GHStriffRequestInfo ghStriffRequestInfo = gh.striffRequestInfo(owner, repo, pullNo);
        LOGGER.info("GitHub Striff Request Metadata:\n" + ghStriffRequestInfo.toString());
        LOGGER.info("Checking if an existing Striff Operation matching this request already exists...");
        GHStriffResultInfo ghStriffResultInfo = this.gHStriffResultInfoRepository
                .findByBaseRepoOwnerAndBaseRepoNameAndBaseBranchShaAndHeadRepoOwnerAndHeadRepoNameAndHeadBranchSha(
                        ghStriffRequestInfo.getBaseRepoOwner(), ghStriffRequestInfo.getBaseRepoName(),
                        ghStriffRequestInfo.getBaseSha(), ghStriffRequestInfo.getHeadRepoOwner(),
                        ghStriffRequestInfo.getHeadRepoName(), ghStriffRequestInfo.getHeadSha());
        if (ghStriffResultInfo == null) {
            LOGGER.info("Nothing found, starting new Striff operation...");
            List<StriffMetadata> striffs = new GitHubStriffProcessor().striffs(
                    ghStriffRequestInfo, gh);
            ghStriffResultInfo = new GHStriffResultInfo(ghStriffRequestInfo, striffs);
            this.gHStriffResultInfoRepository.save(ghStriffResultInfo);
        } else {
            LOGGER.info("Existing striff operation found...");
        }
        LOGGER.info(
                "Returning striff operation metadata for operation id: " + ghStriffResultInfo.getOperationId() + ".");
        return ghStriffResultInfo;
    }

    /**
     * Accepts two pre-signed URLs representing the before and after versions of the
     * code base,
     * along with request info fields, downloads them in parallel, and processes the
     * zip files as ZipInputStreams.
     */
    @PostMapping(value = STRIFF_URI
            + "/owners/{owner}/repos/{repo}/pulls/{pull_id}", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public GHStriffResultInfo compareZipsFromUrls(
            @PathVariable("owner") String owner,
            @PathVariable("repo") String repo,
            @PathVariable("pull_id") String pullNo,
            @RequestParam(value = "before", required = true) MultipartFile afterZip,
            @RequestParam(value = "after", required = true) MultipartFile beforeZip,
            @RequestParam(value = "headRepoOwner", required = true) String headRepoOwner,
            @RequestParam(value = "headRepoName", required = true) String headRepoName,
            @RequestParam(value = "headSha", required = true) String headSha,
            @RequestParam(value = "baseRepoOwner", required = true) String baseRepoOwner,
            @RequestParam(value = "baseRepoName", required = true) String baseRepoName,
            @RequestParam(value = "baseSha", required = true) String baseSha,
            @RequestParam(value = "pullURL", required = true) String pullURL,
            @RequestParam(value = "pullId", required = true) String pullId,
            @RequestParam(value = "updated_at", required = true) String updatedAt,
            @RequestParam(value = "gh_hostname", defaultValue = "api.github.com") String ghHostName) throws Exception {

        // Build the request info object from params
        GHStriffRequestInfo ghStriffRequestInfo = new GHStriffRequestInfo(
                headRepoOwner,
                headRepoName,
                headSha,
                baseRepoOwner,
                baseRepoName,
                baseSha,
                pullURL,
                pullNo,
                pullId);
        LOGGER.info("GitHub Striff Request Metadata:\n" + ghStriffRequestInfo.toString());
        LOGGER.info("Checking if an existing Striff Operation matching this request already exists...");
        GHStriffResultInfo ghStriffResultInfo = this.gHStriffResultInfoRepository
                .findByBaseRepoOwnerAndBaseRepoNameAndBaseBranchShaAndHeadRepoOwnerAndHeadRepoNameAndHeadBranchSha(
                        ghStriffRequestInfo.getBaseRepoOwner(), ghStriffRequestInfo.getBaseRepoName(),
                        ghStriffRequestInfo.getBaseSha(), ghStriffRequestInfo.getHeadRepoOwner(),
                        ghStriffRequestInfo.getHeadRepoName(), ghStriffRequestInfo.getHeadSha());
        if (ghStriffResultInfo == null) {
            LOGGER.info("Nothing found, starting new Striff operation...");
            ZipInputStream afterZIS = validateAndOpenZip(afterZip);
            ZipInputStream beforeZIS = validateAndOpenZip(beforeZip);
            List<StriffMetadata> striffs = new StriffProcessor().process(new ProjectFiles(beforeZIS),
                    new ProjectFiles(afterZIS), "github");
            ghStriffResultInfo = new GHStriffResultInfo(ghStriffRequestInfo, striffs);
        this.gHStriffResultInfoRepository.save(ghStriffResultInfo);
        } else {
            LOGGER.info("Existing striff operation found...");
        }
        LOGGER.info(
                "Returning striff operation metadata for operation id: " + ghStriffResultInfo.getOperationId() + ".");
        return ghStriffResultInfo;
    }

    private ZipInputStream validateAndOpenZip(MultipartFile file) throws IOException {
        String filename = (file != null) ? file.getOriginalFilename() : "unknown";
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Uploaded file '" + filename + "' must not be null or empty.");
        }
        if (!filename.toLowerCase().endsWith(".zip")) {
            throw new IllegalArgumentException("Uploaded file '" + filename + "' must be a .zip archive.");
        }
        return new ZipInputStream(file.getInputStream());
    }
}
