# striff-api
 
Main API for consuming striffs. Build and publish the docker image Using ```mvn package 
docker:build```.

### Continuous Deployment

When deploying for the first time, set GitHub Secret `BRAND_NEW_DEPLOYMENT` to `true` 
and ensure that an existing ECS cluster, Certificate and DNS record does not exist in the AWS 
environment.

When re-deploying a live stack, ensure the GitHub Secret `BRAND_NEW_DEPLOYMENT` is set to `false`.

