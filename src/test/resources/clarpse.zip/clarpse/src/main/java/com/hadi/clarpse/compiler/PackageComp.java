package com.hadi.clarpse.compiler;

import com.hadi.clarpse.sourcemodel.Package;

import java.util.Comparator;

public class PackageComp implements Comparator<Package> {
    @Override
    public int compare(Package o1, Package o2) {
        if (o1.equals(o2)) {
            return 0;
        } else {
            return o2.path().length() <= o1.path().length() ? -1 : 1;
        }
    }
}
